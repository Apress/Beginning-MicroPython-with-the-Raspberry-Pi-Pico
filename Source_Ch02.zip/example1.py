"""example1.py"""
#
# Beginning MicroPython - Chapter 2
#
# Example 1 - Blink the LED
#
# Dr. Charles Bell
#
import time
from machine import Pin # Import the Pin class from the machine library

led = Pin(25, Pin.OUT)  # Get the LED instance (from GPIO pin 25)

led.off()               # Make sure it's off first
for i in range(0, 20):  # Run the indented code 20 times
    led.on()            # Turn LED on
    time.sleep(0.250)   # Wait for 250 milleseconds
    led.off()           # Turn LED off
    time.sleep(0.250)   # Wait for 250 milleseconds

led.off()               # Turn the LED off at the end
print("Done!")          # Goodbye!
