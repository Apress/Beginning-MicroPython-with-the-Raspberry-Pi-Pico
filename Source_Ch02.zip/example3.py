"""example3.py"""
#
# Beginning MicroPython - Chapter 2
#
# Example 3 - Blink the LED with a Timer
#
# Dr. Charles Bell
#
import time
from machine import Pin, Timer

# Constants
SLEEP_TIME = 0.250           # Time to sleep in milliseconds

# Create a timer callback method to toggle the LED
def blink_led(timer):
    """Blink the onboard LED"""
    led.toggle()             # Toggle the LED
    time.sleep(SLEEP_TIME)
    led.toggle()             # Toggle the LED
    time.sleep(SLEEP_TIME)

led = Pin(25, Pin.OUT)       # Get the LED instance (from GPIO pin 25)
timer = Timer()              # Get the timer instance
led.off()                    # Make sure it's off first

# Use a timer to control the blink twice per second or
# every 500 milliseconds
timer.init(freq=2.0, mode=Timer.PERIODIC, callback=blink_led)
time.sleep(10)               # Wait for 10 seconds
timer.deinit()               # Turn off the timer

led.off()
print("Done!")               # Goodbye!
