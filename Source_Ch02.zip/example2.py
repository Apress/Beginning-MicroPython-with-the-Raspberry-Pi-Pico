"""example2.py"""
#
# Beginning MicroPython - Chapter 2
#
# Example 2 - Toggle the LED
#
# Dr. Charles Bell
#
# pylint: disable=invalid-name
import time
from machine import Pin

# Constants
SLEEP_TIME = 0.250           # Time to sleep in milliseconds
MAX_BLINKS = 20              # Max number of blinks

# Create a method to toggle the LED and wait 250 milliseconds
def blink_led():
    """Blink the onboard LED"""
    led.toggle()             # Toggle the LED
    time.sleep(SLEEP_TIME)
    led.toggle()             # Toggle the LED
    time.sleep(SLEEP_TIME)

led = Pin(25, Pin.OUT)       # Get the LED instance (from GPIO pin 25)

led.off()                    # Make sure it's off first
count = 0                    # Initialize the counter
while count < MAX_BLINKS:  # Run while counter < max num blinks
    blink_led()              # Toggle the LED
    count = count + 1        # Increment the counter
led.off()                    # Turn the LED off at the end
print("Done!")               # Goodbye!
