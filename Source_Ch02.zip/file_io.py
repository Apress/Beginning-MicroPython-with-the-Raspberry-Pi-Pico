"""file_io.py"""
#
# Beginning MicroPython - Chapter 2
#
# File I/O Example
#
# Example code to demonstrate writing and reading data to/from files
#
# Dr. Charles Bell 2021
#
# Step 1: Create a file and write some data
with open("log.txt", "w") as new_file:    # use "write" mode
    new_file.write("1,apples,2.5\n")   # write some data
    new_file.write("2,oranges,1\n")    # write some data
    new_file.write("3,peaches,3\n")    # write some data
    new_file.write("4,grapes,21\n")    # write some data

# Step 2: Open a file and read data
with open("log.txt", "r") as old_file:  # use "read" mode
    # Use a loop to read all rows in the file
    for row in old_file.readlines():
        columns = row.strip("\n").split(",") # split row by commas
        print(" : ".join(columns))  # print the row with colon separator
