#
# Beginning MicroPython
#
# Chapter 08 – Soil Moisture
#
# This file contains a class to read one or more soil
# moisture sensors. 
#
# Dr. Charles Bell
#
# Import libraries
from machine import ADC, Pin
from utime import sleep

# Thresholds for the sensors
LOWER_THRESHOLD = 500
UPPER_THRESHOLD = 2500
UPDATE_FREQ = 120   # seconds

    
class SoilMoisture:
    """
    This class reads soil moisture from one or more sensors and writes the
    data to a comma-separated value (csv) file as specified in the constructor.
    
    It also requires a list (array) or sensor dictionaries in the following form.

    sensor = {
      'pin': sensor_pin,
      'power': power_pin,
      'location': location or description
      'nick': nickname for the sensor
    }
    
    Sensors are numbered in the order they appear in the list.
    
    Note: Intermediate calls to get_values() will return the last
    value(s) read or None if no sensors have been read. 
    """

    # Initialization for the class (the constructor)
    def __init__(self, rtc, csv_filename, sensor_list):
        self.rtc = rtc

        # Try to access the file system and make the new path
        self.sensor_file = csv_filename

        # Loop through the sensors specified and setup a new dictionary
        # for each sensor that includes the power and ADC pins defined.
        self.sensors = []
        for sensor in sensor_list:
            # Setup the dictionary for each soil moisture sensor
            soil_moisture = {
                'sensor': ADC(Pin(sensor['pin'])),
                'power': Pin(sensor['power'], Pin.OUT),
                'location': sensor['location'],
                'nick': sensor['nick']
            }
            self.sensors.append(soil_moisture)
 
        self.values_read = None
        print("Soil moisture sensors are ready...")

    # Clear the log
    def clear_log(self):
        log_file = open(self.sensor_file, 'w')
        log_file.close()

    # Get the values read
    def get_values(self):
        return self.values_read

    # Format the time (epoch) for a better view
    def _format_time(self):
        # Get datetime
        dt = self.rtc.datetime()
        return "{0:02}/{1:02}/{2:04} {3:02}:{4:02}:{5:02}".format(dt[1], dt[2], dt[0],
                                                                  dt[4], dt[5], dt[6])
    # Read the sensor 10 times and average the values read
    def _get_value(self, adc, power):
        total = 0
        # Turn power on
        power.high()
        for i in range (0,10):
            # Wait for sensor to power on and settle
            sleep(5)
            # Read the value
            value = adc.read_u16()
            total += value
        # Turn sensor off
        power.low()
        return int(total/10)

    # Monitor the sensors, read the values and save them
    def read_sensors(self):
        log_file = open(self.sensor_file, 'a')
        self.values_read = []
        for sensor in self.sensors:
            # Read the data from the sensor and convert the value
            value = self._get_value(sensor['sensor'], sensor['power'])
            print("Value read: {0}".format(value))
            # datetime,num,value,enum,location
            message = ("{0},{1},{2},{3},{4}"
                       "".format(self._format_time(), sensor['nick'], value,
                                 self._convert_value(value), sensor['location']))
            log_file.write("{0}\n".format(message))
            value_read = {
                'timestamp': self._format_time(),
                'raw_value': value,
                'value': self._convert_value(value),
                'location': sensor['location'],
                'nick': sensor['nick']
            }
            self.values_read.append(value_read)
        log_file.close()

    # Convert the raw sensor value to an enumeration
    def _convert_value(self, value):
        # If value is less than lower threshold, soil is dry else if it
        # is greater than upper threshold, it is wet, else all is well.
        if (value <= LOWER_THRESHOLD):
            return "dry"
        elif (value >= UPPER_THRESHOLD):
            return "wet"
        return "ok"
