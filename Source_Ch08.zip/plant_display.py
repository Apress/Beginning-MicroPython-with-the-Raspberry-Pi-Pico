#
# Beginning MicroPython
#
# Chapter 08 – Soil Moisture
#
# This file contains a class to display data from one or more soil
# moisture sensors. 
#
# Dr. Charles Bell
#
# Import libraries
from utime import sleep
import picodisplay as display

# Constants
DEFAULT_FONT_SCALE = 2
WRAP_SIZE = 240
BUTTON_A = 10
BUTTON_B = 20
BUTTON_X = 30
BUTTON_Y = 40
    
class PlantDisplay:
    """
    This class displays data from one or more soil moisture sensors. 
    """

    # Initialization for the class (the constructor)
    def __init__(self):
        # Setup the Pico Display with a bytearray display buffer
        buf = bytearray(display.get_width() * display.get_height() * 2)
        display.init(buf)
        display.set_backlight(0.5)
        self.clear_screen()
        self.display_on = True
        self.led_on = False
        
    # Function to clear the screen
    def clear_screen(self):
        display.set_pen(0, 0, 0)
        display.clear()
        display.update()
        display.set_pen(255, 255, 255)

    # Function to write data to the screen
    def _write_text(self, message, x, y, scale=DEFAULT_FONT_SCALE):
        self.clear_screen()
        display.text(message, x, y, WRAP_SIZE, scale)
        display.update()

    # Turn screen on
    def screen_on(self):
        # Turns on the display and reads the data
        display.set_backlight(0.5)
        self._write_text("Display ON", 10, 10, 3)
        sleep(2)
        self.display_on = True
        
    # Turn screen off
    def screen_off(self):
        # Turns off the display
        self._write_text("Display OFF", 10, 10, 3)
        sleep(2)
        self.clear_screen()
        display.set_backlight(0)
        self.display_on = False

    # Show the data on the LED
    def show_data(self, soil_data):
        y = 40
        self.clear_screen()
        display.text("Plant Monitor", 10, 10, WRAP_SIZE, 3)
        for data in soil_data:
            display.text(data['nick'], 10, y, WRAP_SIZE, 3)
            display.text(str(data["value"]), 105, y, WRAP_SIZE, 3)
            display.text(str(data["raw_value"]), 160, y, WRAP_SIZE, 3)
            y = y + 20
        display.update()
            
    # Clear the screen and write a message.
    def show_message(self, message):
        self._write_text(message, 10, 10, 3)
            
    # Return True if the display is turned on
    def is_screen_on(self):
        return self.display_on
    
    # Return the button pressed or None if no buttons are pressed
    def button_pressed(self):
        if display.is_pressed(display.BUTTON_A):
            return BUTTON_A
        if display.is_pressed(display.BUTTON_B):
            return BUTTON_B
        if display.is_pressed(display.BUTTON_X):
            return BUTTON_X
        if display.is_pressed(display.BUTTON_Y):
            return BUTTON_Y
        return None
    
    # Turn the RGB LED on/off 
    def toggle_led(red, green, blue):
        if self.led_on:
            display.set_led(0, 0, 0)
            self.led_on = False
        else:
            display.set_led(red, green, blue)
            self.led_on = True
            