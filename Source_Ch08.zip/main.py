#
# Beginning MicroPython
#
# Chapter 08 - MicroPython Plant Monitoring
#
# This file contains a class to read one or more soil
# moisture sensors. 
#
# Dr. Charles Bell
#
# Import libraries
from machine import Pin, SoftI2C
from utime import sleep
from project3.plant_display import PlantDisplay, BUTTON_A, BUTTON_B, BUTTON_X, BUTTON_Y
from project3.urtc import DS1307
from project3.soil_moisture import SoilMoisture
from project3.read_timer import ReadEvent
import sys

# Constants
DATA_FILENAME = 'plant_data.csv'

def main():
    # Global variables
    data_read_event = False
    print("Hello! Welcome to the plant monitor program.")
    # Setup the Pico Display
    display = PlantDisplay()
    display.clear_screen()
    # Setup I2C for RTC
    # Note: RGB LED is on 6, 7, and 8. If you use these, the LED will blink when you read the sensor
    sda = Pin(10)
    scl = Pin(11)
    # Software I2C (bit-banging) for the RTC
    i2c = SoftI2C(sda=sda, scl=scl, freq=100000)
    # Initialize class instance variables for the RTC
    rtc = DS1307(i2c)
    #start_datetime = (2021, 08, 12, 5, 14, 54, 22)
    #rtc.datetime(start_datetime)
    # Setup the sensors
    sensor_list = [
        {
            'pin': 27,
            'power': 21,
            'location': 'Green ceramic pot on top shelf',
            'nick': 'Ivy',
        },        
        {
            'pin': 28,
            'power': 22,
            'location': 'Fern on bottom shelf',
            'nick': 'Fern',
        }    
    ]
    # Setup the soil moisture object instance from the SoilMoisture class
    plants = SoilMoisture(rtc, DATA_FILENAME, sensor_list)
    display.show_message("Reading data...")
    data_read_event = ReadEvent()
    while True:
        # Check to see if it is time to read the data
        if data_read_event.time_to_read():
            data_read_event.reset() 
            if display.is_screen_on():
                print("Reading data...")
                plants.read_sensors()
                values = plants.get_values()
                display.show_data(values)
        sleep(1)
        # Check to see if a button was pressed
        button_pressed = display.button_pressed()
        if not button_pressed:
            continue
        print("Button pressed", button_pressed)
        # Turning the log off only works when the screen is on.
        if button_pressed == BUTTON_A and display.is_screen_on():
            # Clear the log.
            display.show_message("Press B to clear the log.")
            # wait for 5 seconds then ignore the call
            for i in range(10):
                if display.button_pressed() == BUTTON_B:
                    display.show_message("Log cleared.")
                    print('Requesting clear log.')
                    plants.clear_log()
                    sleep(2)
                    display.show_message("Reading data...")
                    data_read_event.reset()
                    break
                else:
                    sleep(0.5)
        # Allow user to turn on the screen if it is off
        elif button_pressed == BUTTON_X and not display.is_screen_on():
            display.screen_on()
            display.show_message("Reading data...")
            data_read_event.reset()
        # Allow user to turn off the screen if it is on
        elif button_pressed == BUTTON_Y and display.is_screen_on():
            display.screen_off()
        sleep(1)

if __name__ == '__main__':
    try:
        main()
    except (KeyboardInterrupt, SystemExit) as err:
        print("\nbye!")
        sys.exit(0)