#
# Beginning MicroPython
#
# Chapter 08 - MicroPython Plant Monitoring
#
# This file contains code to capture the range of values
# for a soil moisture sensor. 
#
# Dr. Charles Bell
#
# Import libraries
from machine import ADC, Pin
from utime import sleep

print("Beginning MicroPython - Soil Moisture threshold test.")
# Setup the GPIO pin for powering the sensor. We use Pin 19
power = Pin(21, Pin.OUT)
# Setup the ADC for the signal pin
adc = ADC(Pin(27))
# Turn sensor off
power.low()

# Loop 10 times and average the values read
print("Reading 10 values.")
total = 0
for i in range (0,10):
    # Turn power on
    power.high()
    # Wait for sensor to power on and settle
    sleep(5)
    # Read the value
    value = adc.read_u16()
    print("Value read ({0:02}): {1}".format(i+1, value))
    total += value
    # Turn sensor off
    power.low()

# Now average the values
print("The average value read is: {0}".format(total/10))

    
