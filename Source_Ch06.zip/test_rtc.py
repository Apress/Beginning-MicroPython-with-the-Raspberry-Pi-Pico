from project1.urtc import DS1307
from utime import sleep
from machine import Pin, SoftI2C

sda = Pin(8)
scl = Pin(9)
i2c = SoftI2C(sda=sda,scl=scl,freq=100000)
rtc = DS1307(i2c)

start_datetime = (2017,07,20,4,9,0,0,0)
rtc.datetime(start_datetime)
for i in range(0,10):
    # Get datetime
    dt = rtc.datetime()
    print("\nTest:", i+1)
    # Print the date
    print("Date: {0:02}/{1:02}/{2:04}".format(dt[1], dt[2], dt[0]))
    # Print the time
    print("Time: {0:02}:{1:02}:{2:02}".format(dt[4], dt[5], dt[6]))
    sleep(3)
