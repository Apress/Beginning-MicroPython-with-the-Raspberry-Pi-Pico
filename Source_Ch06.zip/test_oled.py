from project1.ssd1306 import SSD1306_SPI
from machine import Pin, SPI
from utime import sleep_ms

spi = SPI(0, 100000, mosi=Pin(19), sck=Pin(18))
oled = SSD1306_SPI(128, 32, spi, dc=Pin(17), res=Pin(20), cs=Pin(16))
for i in range(40):
    for j in range(32):
        oled.fill(0)
        oled.show()
        oled.text("HELLO WORLD",i,j)
        oled.show()
        sleep_ms(100)

