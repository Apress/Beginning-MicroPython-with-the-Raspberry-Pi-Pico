#
# Beginning MicroPython
#
# Chapter 06 - Digital Timepiece
#
# This example uses an I2C real time clock (RTC) to store the current
# date and time. It displays the time, date, and day of the week on
# an SPI OLED.
#
# Dr. Charles Bell
#
# Import libraries
from project1.urtc import DS1307
from project1.ssd1306 import SSD1306_SPI
from utime import sleep
from machine import SPI, Pin, SoftI2C

# Return a string to print the day of the week
def get_weekday(day):
    if day == 1: return "Sunday"
    elif day == 2: return "Monday"
    elif day == 3: return "Tuesday"
    elif day == 4: return "Wednesday"
    elif day == 5: return "Thursday"
    elif day == 6: return "Friday"
    else: return "Saturday"

# Display the date and time
def write_time(oled, rtc):
    # Get datetime
    dt = rtc.datetime()
    # Print the date
    oled.text("Date: {0:02}/{1:02}/{2:04}".format(dt[1], dt[2], dt[0]), 0, 0)
    # Print the time
    oled.text("Time: {0:02}:{1:02}:{2:02}".format(dt[4], dt[5], dt[6]), 0, 10)
    # Print the day of the week
    oled.text("Day:  {0}".format(get_weekday(dt[3])), 0, 20)
    # Update the OLED
    oled.show()

# Clear the screen
def clear_screen(oled):
    oled.fill(0)
    oled.show()

def main():
    sda = Pin(8)
    scl = Pin(9)
    # Software I2C (bit-banging) for the RTC
    i2c = SoftI2C(sda=sda, scl=scl, freq=100000)
    # SPI for the OLED
    spi = SPI(0, 100000, mosi=Pin(19), sck=Pin(18))
    # Initialize class instance variables for RTC, OLED
    rtc = DS1307(i2c)
    #start_datetime = (2021, 08, 12, 5, 14, 54, 22)
    #rtc.datetime(start_datetime)
    oled = SSD1306_SPI(128, 32, spi, dc=Pin(17), res=Pin(20), cs=Pin(16))
    for i in range(10):
        clear_screen(oled)
        write_time(oled, rtc)
        sleep(1)

if __name__ == '__main__':
    try:
        main()
    except (KeyboardInterrupt, SystemExit) as err:
        print("\nbye!")
        sys.exit(0)


