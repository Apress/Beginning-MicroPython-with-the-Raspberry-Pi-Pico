from ssd1306 import SSD1306_SPI
from machine import SPI, Pin, SoftI2C

spi = SPI(0, 100000, mosi=Pin(19), sck=Pin(18))
oled = SSD1306_SPI(128, 32, spi, dc=Pin(17), res=Pin(20), cs=Pin(16))
oled.fill(0)
oled.show()
print("OLED screen cleared.")
