"""listing_04_06.py"""
#
# Beginning MicroPython - Chapter 4
#
# Example of using the I2C interface via a driver
# for the Adafruit RGB Sensor tcs34725
#
# Requires library:
# https://github.com/adafruit/micropython-adafruit-tcs34725
#
from machine import I2C, SoftI2C, Pin
import sys
import tcs34725
import utime

# Method to read sensor and display results
def read_sensor(rgb_sense, led):
    sys.stdout.write("Place object in front of sensor now...")
    led.value(1)                 # Turn on the LED
    utime.sleep(5)               # Wait 5 seconds
    sys.stdout.write("reading.\n")
    data = rgb_sense.read(True)  # Get the RGBC values
    print("Color Detected: {")
    print("    Red: {0:03}".format(data[0]))
    print("  Green: {0:03}".format(data[1]))
    print("   Blue: {0:03}".format(data[2]))
    print("  Clear: {0:03}".format(data[3]))
    print("}\n")
    led.value(0)

# Setup the I2C - easy, yes?
sda = Pin(8)
scl = Pin(9)
# Option 1: Hardware I2C (low-level hardware support)
#i2c = I2C(0,sda=sda,scl=scl,freq=400000)
# Option 2: Software I2C (bit-banging)
i2c = SoftI2C(sda=sda,scl=scl,freq=400000)
print("I2C Devices found:", end="")
for addr in i2c.scan():
    print("{0} ".format(hex(addr)))
print("")

# Setup the sensor
sensor = tcs34725.TCS34725(i2c)

# Setup the LED pin
led_pin = Pin(15, Pin.OUT)
led_pin.value(0)
print("Reading object color every 10 seconds.")
print("When LED is on, place object in front of sensor.")
print("Press CTRL-C to quit.")
while True:
    utime.sleep(10)               # Sleep for 10 seconds
    read_sensor(sensor, led_pin)  # Read sensor and display values

