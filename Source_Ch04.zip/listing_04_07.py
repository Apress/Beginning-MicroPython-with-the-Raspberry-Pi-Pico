"""listing_04_07.py"""
#
# Beginning MicroPython - Chapter 4
#
# Example of using the SPI interface via direct access
# for the Adafruit Thermocouple Module MAX31855
#
from machine import Pin, SPI, SoftSPI
import utime

# Create a method to normalize the data into degrees Celsius
def normalize_data(data):
    temp = data[0] << 8 | data[1]
    if temp & 0x0001:
        return float('NaN')
    temp >>= 2
    if temp & 0x2000:
        temp -= 16384
    return (temp * 0.25)

spi_cs = Pin(1)
spi = SPI(0, baudrate=1000000, sck=Pin(6), miso=Pin(4), mosi=Pin(3))
spi_cs.high()

# read from the chip
print("Reading temperature every second.")
print("Press CTRL-C to stop.")
while True:
    spi_cs.low()
    utime.sleep(1)
    print("Temperature is {:05.2F} C".format(normalize_data(spi.read(4))))
    spi_cs.high()
