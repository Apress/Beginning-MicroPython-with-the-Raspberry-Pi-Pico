# Beginning MicroPython - Chapter 4: Listing 4-2
# Example use of the uio library
# Note: change uio to io to run this on your PC!
import uio
try:
    fio_out = uio.open('data.bin', 'wb')
    fio_out.write(b"\x5F\x9E\xAE\x09\x3E\x96\x68\x65\x6C\x6C\x6F")
    fio_out.write(b"\x00")
    fio_out.close()
except Exception as err:
    print("ERROR (writing):", err)
    
# Read the binary file and print out the results in hex and char.
try:
    fio_in = uio.open('data.bin', 'rb')
    print("Raw,Dec,Hex from file:")
    byte_val = fio_in.read(1)  # read a byte
    while byte_val:
        print(byte_val, ",", ord(byte_val), hex(ord(byte_val)))
        byte_val = fio_in.read(1)  # read a byte
    fio_in.close()
except Exception as err:
    print("ERROR (reading):", err)
