# Beginning MicroPython - Chapter 4
# Example use of the uos library
# Note: change uos to os to run it on your PC!
import sys
import uos

# Create a function to display files in directory
def show_files():
    files = uos.listdir()
    sys.stdout.write("\nShow Files Output:\n")
    sys.stdout.write("\tname\tsize\n")
    for file in files:
        stats = uos.stat(file)
        # Print a directory with a "d" prefix and the size
        is_dir = True
        if stats[0] > 16384:
            is_dir = False
        if is_dir:
            sys.stdout.write("d\t")
        else:
            sys.stdout.write("\t")
        sys.stdout.write(file)
        if not is_dir:
            sys.stdout.write("\t")
            sys.stdout.write(str(stats[6]))
        sys.stdout.write("\n")

# List the current directory
show_files()

# Create a directory
uos.mkdir("test")
show_files()
