#
# Beginning MicroPython
#
# Chapter 14 - ThingSpeak MicroPython
#
# This example demonstrates how to write data to a ThingSpeak
# channel. It shows you the most basic of operations to get
# started using ThingSpeak in your Pico projects.
#
# Dr. Charles Bell
#
# Import libraries
import random
import sys
import time
from thingspeak import ThingSpeak

# API KEY
THINGSPEAK_APIKEY = 'YOUR_WRITE_API_KEY_HERE'

def main():
    """main"""
    print("Welcome to the ThingSpeak Raspberry Pi Pico demonstration!")
    print("Press CTRL+C to stop.")
    thing_speak = ThingSpeak(THINGSPEAK_APIKEY, with_debug=True)
    while True:
        # Generate a random integer
        rand_int = random.randint(1, 20)
        print("Random number generated: {}".format(rand_int))
        thing_speak.upload_data({'field1': rand_int})
        # Sleep for 30 seconds
        time.sleep(30)

if __name__ == '__main__':
    try:
        main()
    except (KeyboardInterrupt, SystemExit) as err:
        print("\nbye!\n")
sys.exit(0)
