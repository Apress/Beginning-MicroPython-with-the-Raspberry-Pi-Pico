#
# Beginning MicroPython
#
# Chapter 14 – ThingSpeak
#
# This module contains a class to write data to ThingSpeak.
# You pass in the API key to the constructor. To write data,
# call the upload_data() function passing in dictionary of field
# names and values.
#
# Dr. Charles Bell
#
# Import libraries
import json
import sys
import time
import picowireless
from project9 import ppwhttp

# Constants
MAX_RETRIES = 10
TCP_MODE = const(0)
REQUEST_DELAY = const(30)
THINGSPEAK_PORT = 80
THINGSPEAK_HOST = "api.ThingSpeak.com"
HTTP_HEADERS = """POST /update HTTP/1.1
Host: api.ThingSpeak.com
Accept: */*
Content-Length: {0}
Content-Type: application/json

{1}
"""


class ThingSpeak:
    """This class permits you to upload data to ThingSpeak using your API write key."""

    #
    # __init__()
    #
    # Constructor. Resolve the host address for ThingSpeak, get a client socket.
    #
    # key (str) - your API write key
    # num_retries (int) - number of retries for connect, send operations
    #                     Default = MAX_RETRIES
    # with_debug (bool) - if True, print additional debug statements
    #                     Default = False
    #
    def __init__(self, key, num_retries=MAX_RETRIES, with_debug=False):
        self.api_key = key
        self.max_retries = num_retries
        self.with_debug = with_debug
        self.port = THINGSPEAK_PORT
        # Connect to WiFi
        ppwhttp.start_wifi()
        # Resolve the IP address for ThingSpeak
        self.host_address = picowireless.get_host_by_name(THINGSPEAK_HOST)
        if self.with_debug:
            print("DNS resolved '{}' to {}.{}.{}.{}".format(THINGSPEAK_HOST, *self.host_address))
        # Get a client socket
        self.client_sock = picowireless.get_socket()

    #
    # _connect()
    #
    # Attempt to connect to ThingSpeak to create a client connection.
    #
    # timeout (int) - max time in seconds to wait for response
    #
    # Returns (bool) - True = success, False = failed to connect.
    #
    def _connect(self, timeout=1000):
        picowireless.client_start(self.host_address, self.port, self.client_sock, TCP_MODE)
        t_start = time.time()
        timeout /= 1000.0
        while time.time() - t_start < timeout:
            state = picowireless.get_client_state(self.client_sock)
            if state == 4:
                return True
            time.sleep(1.0)
        return False

    #
    # _disconnect()
    #
    # Stop the client connection.
    #
    def _disconnect(self):
        # Stop the client
        picowireless.client_stop(self.client_sock)

    #
    # upload_data()
    #
    # Upload the data in the form of a dictionary of key, values to ThingSpeak.
    # If number of retries is exceeded, operation is considered failed and an
    # error message is generated.
    #
    # param_dict (dict) - dictionary of fields to add to channel
    #
    # Returns (bool) - True = success, False = failed to connect.
    #
    def upload_data(self, param_dict, timeout=5000):
        if self.with_debug:
            print("parameters: {0}".format(param_dict))
        # Add API key to the dictionary
        param_dict.update({'api_key': self.api_key})
        param_str = json.dumps(param_dict)
        # Attempt to connect to ThingSpeak
        retry = 0
        while retry <= self.max_retries:
            try:
                print("Connecting to ThingSpeak...", end="")
                if not self._connect():
                    print("Connection failed!")
                    return False
                print("connected.")
                break
            except Exception as err:
                print("\nWARNING: ThingSpeak connection failed: {0}".format(err))
                if retry <= self.max_retries:
                    print("Retrying in 5 seconds. [{}]".format(retry+1))
                    time.sleep(5)
                    retry = retry + 1
                else:
                    retry = self.max_retries + 1
                    print("WARNING: Cannot connect to ThingSpeak. Exceeded retries. Abort.")
                    self._disconnect()
                    return False

        # Format the POST to send data to ThingSpeak
        post_header = HTTP_HEADERS.format(len(param_str), param_str).replace("\n", "\r\n")
        if self.with_debug:
            print("POST HEADER:\n", post_header)

        # Attempt to retry if the timeout fails
        retry = 0
        while retry <= self.max_retries:
            try:
                print("Sending data...", end="")
                picowireless.send_data(self.client_sock, post_header)
                print("done.")
                break
            except Exception as err:
                print("\nWARNING: ThingSpeak update failed: {0}".format(err))
                if retry <= self.max_retries:
                    print("Retrying in 5 seconds. [{}]".format(retry+1))
                    time.sleep(5)
                    retry = retry + 1
                else:
                    retry = self.max_retries + 1
                    print("WARNING: Cannot upload to ThingSpeak. Exceeded retries. Abort.")
                    self._disconnect()
                    return False

        response = self._get_response(timeout)
        # Check header for correct status.
        if response["status"] == "200 OK":
            print("Data upload complete.")
        elif response['status'] == "ERROR":
            print("ERROR: {0}".format(response['body']))
        else:
            print("WARNING: data not acknowledged.")
            if self.with_debug:
                print("Header, body: {0}\n{1}".format(response['header'], response['body']))
        self._disconnect()
        return True

    #
    # _get_response()
    #
    # Get the response from the server.
    #
    # Returns dict - response status, header, and body
    #
    def _get_response(self, timeout):
        # Wait for a response
        t_start = time.time()
        while True:
            if time.time() - t_start > timeout:
                picowireless.client_stop(self.client_sock)
                err_msg = ("Timeout waiting for response {0}:{1}"
                           "".format(self.host_address, self.port))
                return {'status':'ERROR', 'header': {}, 'body': err_msg}
            avail_length = picowireless.avail_data(self.client_sock)
            if avail_length > 0:
                break
        if self.with_debug:
            print("Got {} bytes in response.".format(avail_length))

        # Read the response from the server (in bytes)
        response = b""
        while len(response) < avail_length:
            data = picowireless.get_data_buf(self.client_sock)
            response += data
        response = response.decode("utf-8")
        # Break in to the header and body
        head, body = response.split("\r\n\r\n", 1)
        if self.with_debug:
            print("Header:\n", head)
        status = "UNKNOWN"
        # Find the status
        for line in head.split("\r\n")[1:]:
            key, value = line.split(": ", 1)
            if key == 'Status':
                status = value
                break
        return {'status': status, 'header': head, 'body': body}

if __name__ == '__main__':
    try:
        sample_params = {'field1': 42}
        api_key = "YOUR_API_KEY_GOES_HERE"
        ThingSpeak = ThingSpeak(api_key, with_debug=True)
        ThingSpeak.upload_data(sample_params)
    except (KeyboardInterrupt, SystemExit) as ex:
        print("\nbye!\n")
    sys.exit(0)
