"""dust_sensor.py"""
#
# Beginning MicroPython
#
# Chapter 12 - Checking the Environment
#
# This code module contains a special function to read data
# from the Shinyei Model PPD42NS Particle Sensor, which is
# implemented on the Grove Dust Sensor.
#
# Note: this code requires 30 seconds to execute. Be sure to
# adjust your sampling time to allow for the sensor sampling
# time requirements.
#
# Dr. Charles Bell
#
import machine
import time

SAMPLETIME_S = 30
DUST_SENSOR_PIN = 20

class DustSensor:
    """DustSensor Class"""
    
    def __init__(self, sensor_pin=DUST_SENSOR_PIN):
        """Constructor"""
        # Setup dust sensor
        self.dust_sensor_pin = machine.Pin(sensor_pin, machine.Pin.IN)
        self.last_reading = 0.62 # Minimal value possible from data sheet
        
    def read(self):
        """Read dust sensor"""
        # start time of sampling window in seconds
        starttime = time.time()
        # ratio of LPO time over the entire sampling window
        ratio = 0
        #  Low Pulse Occupancy Time (LPO Time) in microseconds
        low_pulse_occupancy = 0
        # concentration based on LPO time and characteristics graph (datasheet)
        concentration = 0
        start = 0
        while time.time() - starttime <= SAMPLETIME_S:  # in sampling window
            if self.dust_sensor_pin.value() == 0:
                start = time.ticks_us()
            elif start > 0:
                value = time.ticks_diff(time.ticks_us(), start)
                # Low Pulse Occupancy Time (LPO Time) in microseconds
                low_pulse_occupancy += value
                start = 0

        # ratio: percentage of low pulses over the sampling window
        ratio = low_pulse_occupancy / (SAMPLETIME_S * 1e+6)
        concentration = 1.1 * (ratio ** 3) - 3.8 * (ratio ** 2) + 520 * ratio + 0.62
        if concentration != 0.62:
            print("> PM concentration: {} pcs/0.01cf".format(concentration))
            self.last_reading = concentration
        else:
            concentration = self.last_reading
            print("> PM last reading: {} pcs/0.01cf".format(concentration))
        return concentration

if __name__ == '__main__':
    try:
        # Setup dust sensor
        dust_sensor = DustSensor()
        while True:
            print("Reading dust sensor...")
            print("Dust = {}".format(dust_sensor.read()))
            time.sleep(5)

    except (KeyboardInterrupt, SystemExit) as err:
        print("\nbye!\n")
