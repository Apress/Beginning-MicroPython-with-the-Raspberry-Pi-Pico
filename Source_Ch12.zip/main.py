"""main.py"""
#
# Beginning MicroPython
#
# Chapter 12 - Checking the Environment
#
# This example uses a set of sensors to sample the air quality for
# indoor use. Sensors include a barometer, thermometer, dust sensor,
# and a general gas detector. It also uses a buzzer to beep if the
# data read exceeds specified parameters.

# All sensors are contained in the AirMonitor class with the buzzer
# and OLED supported in the main sketch. All library instances are
# dynamically allocated.
#
# The data is displayed on a small OLED. Should the dust concentration
# or the air quality or temperature exceed the thresholds, a message
# will be displayed on the OLED warning of poor air quality and the
# buzzer will beep 5 times.
#
# Note that some of the sensors have differing sample rates and
# start up times. The following lists the limits of those sensors.
#
# - Dust sensor : reads every 30 seconds
# - Air quality : requires 20 second startup and 2+ second read time
#
# Dr. Charles Bell
#

# Import libraries
from machine import Pin, I2C
import time
import sys
from project6.air_monitor import AirMonitor, AIR_POOR, AIR_FAIR, AIR_GOOD, AIR_ERR
from project6.ssd1306 import SSD1306_I2C

# Constants
SAMPLING_RATE = 5 # 5 second wait to start next read
BUZZER_PIN = 26
WARNING_BEEPS = 5
HIGH = 1
LOW = 0

# Constants for environmental quality
MAX_TEMP = 30.0
MAX_DUST = 40.0

#
# beep()
#
# Use this function to play a tone on the buzzer for
# the specified time.
#
# buzzer_pin (Pin) - Pin class instance
# duration (int) - Duration of the tone. Default = 150ms
#
def beep(buzzer_pin, duration=0.150):
    """beep"""
    buzzer_pin.on()
    time.sleep(duration)
    buzzer_pin.off()

#
# oled_write()
#
# Use this function to write to the oled using a
# single function similar to the Arduino version
#
# oled (ssd1306) - OLED class instance
# column (int) - column "x" to start print
# row (int) - row "x" to start print
#
def oled_write(oled, column, row, message):
    """oled_write"""
    oled.text(message, column*8, row*8, 255)
    oled.show()

#
# setup_oled()
#
# Use this function to setup the OLED
#
# i2c (I2C) - I2C class instance
#
# Returns ssd1306 class instance
#
def setup_oled(i2c):
    """setup_oled"""
    # Setup OLED
    display = SSD1306_I2C(128, 64, i2c)  # Grove OLED Display
    display.text('Hello World', 0, 0, 255)
    display.show()
    oled_write(display, 0, 1, "Environment")
    oled_write(display, 0, 2, "Monitor")
    oled_write(display, 0, 4, "Starting...")
    return display

#
# main()
#
# Main script to run the Environment Monitor project.
#
def main():
    """Main"""
    print("Welcome to the Environment Monitor!")
    # Setup buzzer
    buzzer = Pin(BUZZER_PIN, Pin.OUT)
    i2c = I2C(0,scl=Pin(9), sda=Pin(8), freq=100000)
    print("Hello. I2C devices found: {}".format(i2c.scan()))
    oled = setup_oled(i2c)
    # Start the AirMonitor
    air_quality = AirMonitor(i2c)
    time.sleep(3)
    oled_write(oled, 11, 4, "done")
    beep(buzzer)
    oled.fill(0)
    oled.show()

    while True:
        if air_quality.read_data():
            # Retrieve the data
            env_data = air_quality.get_data()

            oled_write(oled, 0, 0, "ENVIRONMENT DATA")
            oled_write(oled, 0, 2, "Temp: ")
            oled_write(oled, 5, 2, "{:3.2f}C".format(env_data["temperature"]))
            oled_write(oled, 0, 3, "Pres: ")
            oled_write(oled, 5, 3, "{:05.2f}hPa".format(env_data["pressure"]))
            oled_write(oled, 0, 4, "Dust: ")
            if env_data["dust_concentration"] == 0.0:
                oled_write(oled, 5, 4, "--         ")
            else:
                oled_write(oled, 5, 4, "{:06.2f}%".format(env_data["dust_concentration"]))
            oled_write(oled, 0, 5, "airQ: ")
            if env_data["air_quality"] in {AIR_ERR, AIR_POOR}:
                oled_write(oled, 5, 5, "POOR")
            elif env_data["air_quality"] == AIR_FAIR:
                oled_write(oled, 5, 5, "FAIR")
            elif env_data["air_quality"] == AIR_GOOD:
                oled_write(oled, 5, 5, "GOOD")
            else:
                oled_write(oled, 5, 5, "--       ")

            # Check for environmental quality
            if ((env_data["dust_concentration"] > MAX_DUST) or
                    (env_data["temperature"] > MAX_TEMP) or
                    (env_data["air_quality"] == AIR_POOR) or
                    (env_data["air_quality"] == AIR_ERR)):
                #pylint: disable=unused-variable
                for i in range(0, WARNING_BEEPS):
                    oled_write(oled, 3, 7, "ENV NOT OK")
                    beep(0.250)
                    time.sleep(0.250)
                    oled_write(oled, 3, 7, "          ")
                    time.sleep(0.250)

        else:
            oled.fill(0)
            oled.show()
            oled_write(oled, 0, 2, "ERROR! CANNOT")
            oled_write(oled, 0, 3, "READ DATA")

        time.sleep(SAMPLING_RATE)

if __name__ == '__main__':
    try:
        main()
    except (KeyboardInterrupt, SystemExit) as err:
        print("\nbye!\n")
sys.exit(0)
