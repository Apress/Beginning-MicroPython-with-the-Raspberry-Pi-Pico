"""air_monitor.py"""
#
# Beginning MicroPython
#
# Chapter 12 - Checking the Environment
#
# This code module contains the AirMonitor class that
# defines the functions and data for the class for working
# with the dust sensor, air quality, temperature, and barometer
# Grove modules.
#
# Functions include reading data and retrieving the values
# using get functions.
#
# Dr. Charles Bell
#
from machine import ADC, I2C, Pin
import time
from project6.bmx280x import BMX280
from project6.mcp9808 import MCP9808
from project6.dust_sensor import DustSensor

# Constants
DUST_SAMPLE_RATE = 60 # 60 seconds
AIR_SENSOR_PIN = 1
AIR_POOR = 0
AIR_FAIR = 1
AIR_GOOD = 2
AIR_ERR = 3

class AirMonitor:
    """AirMonitor Class"""

    data = {
        "temperature": 0.0,
        "pressure": 0.0,
        "dust_concentration": 0.0,
        "air_quality": AIR_GOOD,
    }
 
    #
    # constructor
    #
    # Setup the sensors.
    #
    def __init__(self, i2c):
        """Constructor"""

        # Initialize the BMP280
        self.i2c = i2c
        # Setup BMP280
        self.bmp280 = BMX280(i2c, 0x77)
        # Setup MCP9808
        self.mcp9808 = MCP9808(i2c)
        # Setup dust sensor
        self.dust_sensor = DustSensor()
        # Setup air quality sensor
        self.air_quality = ADC(28)
        self.to_volts = 5.0 / 1024

    def read_pressure(self):
        """Read the pressure from the BMP280."""
        return self.bmp280.pressure/100
         
    def read_temperature(self):
        """Read the temperature from the BMP280."""
        return self.bmp280.temperature

    def translate(self, x, in_min=1, in_max=65535, out_min=1, out_max=1024):
        """Translate from range 1-65353 to 1-1024."""
        return int((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min)

    #
    # read_data()
    #
    # Reads the data from the sensors. Call this function before
    # the get_data() function to retrieve the data.
    #
    #pylint: disable=broad-except
    def read_data(self):
        """read_data"""
        print("\n>> Reading Data <<")
        # Read temperature
        try:
            print("> Reading temperature = ", end="")
            self.data["temperature"] = self.mcp9808.read_temp()
            print(self.data["temperature"])
        except Exception as err:
            print("ERROR: Cannot read temperature: {}".format(err))
            return False

        # Read pressure
        try:
            print("> Reading pressure = ", end="")
            self.data["pressure"] = self.read_pressure()
            print(self.data["pressure"])
        except Exception as err:
            print("ERROR: Cannot read pressure: {}".format(err))
            return False

        # Read dust
        self.data["dust_concentration"] = 0.10
        try:
            print("> Reading dust concentration")
            self.data["dust_concentration"] = self.dust_sensor.read()
            print("> Dust concentration = {}".format(self.data["dust_concentration"]))
        except Exception as err:
            print("ERROR: Cannot read dust concentration: {}".format(err))
            return False

        # Read air quality
        try:
            print("> Reading air quality = ", end="")
            raw_value = self.air_quality.read_u16()
            sensor_value = self.translate(raw_value)            
            if sensor_value > 700:
                self.data["air_quality"] = AIR_POOR
            elif sensor_value > 300:
                self.data["air_quality"] = AIR_FAIR
            else:
                self.data["air_quality"] = AIR_GOOD
            print(self.data["air_quality"])
        except Exception as err:
            print("ERROR: cannot read air quality: {0}".format(err))
            self.data["air_quality"] = AIR_ERR
            return False

        return True

    #
    # get_data()
    #
    # Return the data read from the sensors using a dictionary
    # as follows:
    #
    # temperature - (float) temperature in Celsius
    # concentration - (float) dust concentration percentage
    #
    # Returns (dict) - the environment data dictionary
    #
    def get_data(self):
        """get_data"""
        return self.data

