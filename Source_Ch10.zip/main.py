#
# Beginning MicroPython
#
# Chapter 10 – Sound to Light Detector
#
# This example implements a sound detector that turns on a RGB
# LED based on the value from the sound sensor. We use a Grove
# Sound Sensor and a Grove Chainable RGB LED. 
#
# Dr. Charles Bell
#
# Import libraries
from machine import ADC, Pin
from time import sleep
from project4.p9813 import P9813

# Constants
LOW_THRESHOLD = 10000   # Threshold of the smallest sound value - tune to your environs

# Read the sensor 10 times and average the values read
def get_value(adc):
    total = 0
    for i in range (0,10):
        # Wait for sensor to settle
        sleep(0.1)
        # Read the value
        value = adc.read_u16()
        total += value
    return int(total/10)

# Translate from range 1-65353 to 1-16,777,215
def translate(x, in_min, in_max, out_min, out_max):
    return int((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min)

# Map range 0-0xFFFFFF to (R,G,B) tuple
def num_to_rgb(sensor_value):
    mapped_value = translate(sensor_value, LOW_THRESHOLD, 0xFFFF, 1, 0xFFFFFF)
    r = mapped_value >> 16
    g = (mapped_value >> 8) & 0x00FF
    b = (mapped_value & 0x0000FF)
    return (r,g,b)

def main():
    # Setup the sound sensor
    sound = ADC(Pin(26))

    # Setup the RGB module
    scl = Pin(7, Pin.OUT)
    sda = Pin(6, Pin.OUT)
    rgb_chain = P9813(scl, sda, 1)
    rgb_chain[0] = (0, 0, 0) # turn RGB off
    rgb_chain.write()
    sleep(1)

    print("Welcome to the sound to light detector!")
    while True:
        value = get_value(sound)
        if value > LOW_THRESHOLD:
            rgb = num_to_rgb(value)
            print("Value read: {0:05} Color: {1}".format(value, rgb))
            rgb_chain[0] = rgb
            rgb_chain.write()
            sleep(1)
            continue
        rgb_chain[0] = (0, 0, 0)
        sleep(0.25)
        rgb_chain.write()

if __name__ == '__main__':
    try:
        main()
    except (KeyboardInterrupt, SystemExit):
        print("\nbye!")
        sys.exit(0)
