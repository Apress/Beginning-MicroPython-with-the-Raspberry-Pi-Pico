#
# Beginning MicroPython
#
# Chapter 13 – Pedestrian Crosswalk Web Server Example
#
# This example implements a Pedestrian Crosswalk Simulator
# using a web browser. 
#
# Dr. Charles Bell
#
# Import libraries
from machine import Pin
import _thread
import utime
import sys

# Check for the Pimoroni http class library.
try:
    import project7.ppwhttp
except ImportError:
    raise RuntimeError("Cannot find ppwhttp. Have you copied ppwhttp.py to your Pico?")

# HTML web page for the project
MAIN_PAGE = """<!DOCTYPE html>
<html>
  <head>
    <title>Beginning MicroPython</title>
  </head>
  <center><h2>Pedestrian Crosswalk Simulation</h2></center><br>
  <center>A simple project to demonstrate how to control hardware over the Internet.</center><br><br>
  <form>
    <center>
      <button name="WALK" value = "PLEASE" type="submit" style="height: 50px; width: 100px">REQUEST WALK</button>
    </center>
  </form>
</html>
"""

# Setup the button and LEDs
stoplight_red = Pin(5, Pin.OUT)
stoplight_yellow = Pin(4, Pin.OUT)
stoplight_green = Pin(3, Pin.OUT)
pedestrian_red = Pin(1, Pin.OUT)
pedestrian_green = Pin(0, Pin.OUT)

# Setup lists for the LEDs
stoplight = [stoplight_red, stoplight_yellow, stoplight_green]
pedestrian_signal = [pedestrian_red, pedestrian_green]

#
# cycle_lights()
#
# This function cycles the stoplight and pedestrian_signal. It toggles
# from green to yellow for 2 seconds then red for 20 seconds.
#
def cycle_lights():
    print("START WALK")
    # Go yellow.
    stoplight[2].off()
    stoplight[1].on()
    # Wait 2 seconds
    utime.sleep(2)
    # Go red and turn on walk light
    stoplight[1].off()
    stoplight[0].on()
    utime.sleep_ms(500)  # Give the pedestrian a chance to see it
    pedestrian_signal[0].off()
    pedestrian_signal[1].on()
     # After 10 seconds, start blinking the walk light
    utime.sleep(1)
    for i in range(0,10):
        pedestrian_signal[1].off()
        utime.sleep_ms(500)
        pedestrian_signal[1].on()
        utime.sleep_ms(500)
    # Stop=green, walk=red
    pedestrian_signal[1].off()
    pedestrian_signal[0].on()
    utime.sleep_ms(500)  # Give the pedestrian a chance to see it
    stoplight[0].off()
    stoplight[2].on()
    print("END WALK")

#
# get_home()
#
# This defines the default route for the http server.
#
@ppwhttp.route("/", methods=["GET", "POST"])
def get_home(method, url, data=None):
    return MAIN_PAGE

#
# get_walk()
#
# This function defines the route for requesting the pedestrian
# walk action. It replaces the button from the Chapter 7 example.
#
@ppwhttp.route("/?WALK=PLEASE", methods=["GET"])
def get_walk(method, url, data=None):
    if method == "GET":
        cycle_lights()
    return MAIN_PAGE

#
# server_loop_forever()
#
# Start a server and continuously poll for HTTP requests.
#
def server_loop_forever():
   server_sock = ppwhttp.start_server()
   while True:
       ppwhttp.handle_http_request(server_sock)
       utime.sleep(0.01)

#
# main()
#
# Setup the http server and run the main loop in a thread
def main():
    # Turn off the LEDs
    for led in stoplight:
       led.off()
    for led in pedestrian_signal:
       led.off()

    # Start with green stoplight and red pedestrian_signal
    stoplight[2].on()
    pedestrian_signal[0].on()

    ppwhttp.start_wifi()

    # Handle the server polling loop on the other core!
    _thread.start_new_thread(server_loop_forever, ())

if __name__ == '__main__':
    try:
        main()
    except (KeyboardInterrupt, SystemExit) as err:
        print("\nbye!\n")
sys.exit(0)
