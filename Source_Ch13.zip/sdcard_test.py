from machine import ADC, Pin, SPI
import uos
from project8.sdcard import SDCard
sck_pin = Pin(18, Pin.OUT)
mosi_pin = Pin(19, Pin.OUT)
miso_pin = Pin(16, Pin.OUT)
sd_pin = Pin(22)
sd_spi = SPI(0, sck=sck_pin, mosi=mosi_pin, miso=miso_pin)
sd = SDCard(sd_spi, sd_pin)
uos.mount(sd, "/sd")
f = open("/sd/plant_data.csv")
f.readlines()
f.close()
