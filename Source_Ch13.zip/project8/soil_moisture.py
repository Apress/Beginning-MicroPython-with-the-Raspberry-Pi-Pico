#
# Beginning MicroPython
#
# Chapter 13 – Soil Moisture Web Version
#
# This file contains a class to read one or more soil
# moisture sensors. It has been modified to fit the
# needs of the project8 implementation to save data
# to a file on the SD card present on the Pico Wireless
# Pack from Pimoroni.
#
# Dr. Charles Bell
#
# Import libraries
from machine import ADC, Pin, SPI
import _thread
import uos
from utime import sleep
from project8.sdcard import SDCard

# Constants
LOG_FILE = "/sd/plant_data.csv"
# Thresholds for the sensors
LOWER_THRESHOLD = 500
UPPER_THRESHOLD = 2500
UPDATE_FREQ = 120   # seconds
# Max number of rows to store in memory before writing to disk
CACHE_LIMIT = 2


class SoilMoisture:
    """
    This class reads soil moisture from one or more sensors and writes the
    data to a comma-separated value (csv) file as specified in the constructor.

    It also requires a list (array) or sensor dictionaries in the following form.

    sensor = {
      'pin': sensor_pin,
      'power': power_pin,
      'location': location or description
      'nick': nickname for the sensor
    }

    Sensors are numbered in the order they appear in the list.
    """

    # Initialization for the class (the constructor)
    def __init__(self, rtc, sensor_list):
        # Lock for read/write
        self.rw_lock = _thread.allocate_lock()

        # Setup SD card via SPI
        sck_pin = Pin(18, Pin.OUT)
        mosi_pin = Pin(19, Pin.OUT)
        miso_pin = Pin(16, Pin.OUT)
        sd_pin = Pin(22)
        sd_spi = SPI(0, sck=sck_pin, mosi=mosi_pin, miso=miso_pin)
        sd = SDCard(sd_spi, sd_pin)

        # Mount SD card
        uos.mount(sd, "/sd")

        # If LOG_FILE is not present, create it
        try:
            uos.stat(LOG_FILE)
        except OSError:
            print("Creating log file.\n")
            log_file = open(LOG_FILE, "w")
            log_file.close()
            
        # Load data into memory
        self.cached_values = []
        log_file = open(LOG_FILE, "r")
        print("Reading data from disk...", end="")
        for row in log_file:
            self.cached_values.append(row)
        log_file.close()
        self.values_read = 0
        print("done.")
        
        self.rtc = rtc

        # Loop through the sensors specified and setup a new dictionary
        # for each sensor that includes the power and ADC pins defined.
        self.sensors = []
        sensor_num = 1
        for sensor in sensor_list:
            # Setup the dictionary for each soil moisture sensor
            soil_moisture = {
                'sensor': ADC(Pin(sensor['pin'])),
                'power': Pin(sensor['power'], Pin.OUT),
                'location': sensor['location'],
                'sensor_num': sensor_num
            }
            sensor_num += 1
            self.sensors.append(soil_moisture)
    
    #
    # clear_log()
    #
    # Clear the log removing all rows.
    #
    def clear_log(self):
        print("Clearing log file")
        log_file = open(LOG_FILE, 'w')
        log_file.close()
        # Lock is on the self.cached_values variable
        self.rw_lock.acquire()
        print("Write (clear) lock acquired.")
        self.cached_values = []
        self.values_read = 0
        try:
            self.rw_lock.release()
            print("Write (clear) lock released.")
        except Exception as ex:
            print("ERROR: Cannot release write (clear) lock.", ex)

    #
    # get_html_sensor_data()
    #
    # Read the sensor data from the log file and return as HTML row.
    #
    def get_html_sensor_data(self, HTML_FORMAT_STR):
        html_sensor_data = ""
        self.rw_lock.acquire()
        print("Read lock acquired.")
        for row in self.cached_values:
            cols = row.strip("\n").split(",") # split row by commas         
            html = HTML_FORMAT_STR.format(cols[0], cols[1], cols[2],
                                          cols[3], cols[4])
            html_sensor_data += html
            
        # If there is too much data in the cache, write it to disk.
        if self.values_read >= CACHE_LIMIT:
            start_index = len(self.cached_values) - self.values_read
            self.values_read = 0
            print("Writing cache to disk...", end="")
            try:
                log_file = open(LOG_FILE, 'a')
                for index in range(start_index, len(self.cached_values)):
                    row = self.cached_values[index]
                    log_file.write("{0}\n".format(row))
                log_file.close()
            except Exception as ex:
                print("ERROR: Cannot write cache to disk.", ex)
            print("done.")
        try:
            self.rw_lock.release()
            print("Read lock released.")
        except Exception as ex:
            print("ERROR: Cannot release read lock.", ex)
        return html_sensor_data

    #
    # _get_value()
    #
    # Read the sensor 10 times and average the values read
    #
    def _get_value(self, adc, power):
        total = 0
        # Turn power on
        power.high()
        for i in range (0,10):
            # Wait for sensor to power on and settle
            sleep(1)
            # Read the value
            value = adc.read_u16()
            total += value
        # Turn sensor off
        power.low()
        return int(total/10)

    #
    # read_sensors()
    #
    # Read the sensor values and save them in the cache
    #
    def read_sensors(self):
        for sensor in self.sensors:
            # Read the data from the sensor and convert the value
            value = self._get_value(sensor['sensor'], sensor['power'])
            print("Reading sensor {0} - value: {1}".format(sensor['sensor_num'],
                                                           value))
            value_read = ("{0},{1},{2},{3},{4}"
                          "".format(self.rtc.read_time(), sensor['sensor_num'],
                                    value, self._convert_value(value), sensor['location']))
            self.rw_lock.acquire()
            print("Write lock acquired.")
            self.cached_values.append(value_read)
            self.values_read += 1
            try:
                self.rw_lock.release()
                print("Write lock released.")
            except Exception as ex:
                print("ERROR: Cannot release read lock.", ex)

    #
    # _convert_value()
    #
    # Convert the raw sensor value to an enumeration
    #
    def _convert_value(self, value):
        # If value is less than lower threshold, soil is dry else if it
        # is greater than upper threshold, it is wet, else all is well.
        if (value <= LOWER_THRESHOLD):
            return "dry"
        elif (value >= UPPER_THRESHOLD):
            return "wet"
        return "ok"
