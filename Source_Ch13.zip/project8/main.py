#
# Beginning MicroPython
#
# Chapter 13 – Plant Monitor Web Server Example
#
# This example implements a soil moisture monitor
# using a web browser. It uses a modified SoilMoisture class
# originally seen in Project 3 to read the sensors and
# write the data to a file. The SoilMoisture class is also
# responsible for returning rows formatted using a format
# string passed. This way, all HTML-specific code remains in
# this code file and the soil moisture storage remains in
# the SoilMoisture class.
#
# Dr. Charles Bell
#
# Import libraries
import _thread
import uos
import utime
import sys
from project8.ds3231 import ds3231               # RTC library
from project8.read_timer import ReadEvent        # Read event timer class
from project8.soil_moisture import SoilMoisture  # SoilMoisture class

# Check for the Pimoroni http class library.
try:
    import project8.ppwhttp as ppwhttp
except ImportError:
    raise RuntimeError("Cannot find ppwhttp. Have you copied ppwhttp.py to your Pico?")

# Constants
# HTML web page for the project
HTML_TABLE_ROW = "<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td></tr>"
HTML_REDIRECT = '<meta http-equiv="Refresh" content="0; url=''{0}''" />'

# Global Variables
WEB_PART1 = ""
WEB_PART2 = ""

# Setup code
print("Welcome to the Plant Monitor Web Version!\n")

# Read base HTML pages
with open("/part1.html") as html_file:
    WEB_PART1 = "".join(html_file.readlines())
with open("/part2.html") as html_file:
    WEB_PART2 = "".join(html_file.readlines())

# RTC Setup
I2C_SDA = 20
I2C_SCL = 21
rtc = ds3231(0, I2C_SCL, I2C_SDA)

# Setup Sensors class
sensor_list = [
    {
        'pin': 27,
        'power': 17,
        'location': 'Green ceramic pot on top shelf',
        'nick': 'Ivy',
    },
    {
        'pin': 28,
        'power': 18,
        'location': 'Fern on bottom shelf',
        'nick': 'Fern',
    }
]
# Setup the soil moisture object instance from the SoilMoisture class
plants = SoilMoisture(rtc, sensor_list)

#
# get_home()
#
# This defines the default route for the http server.
#
@ppwhttp.route("/", methods=["GET", "POST"])
def get_home(method, url, data=None):
    # Read data and return web page.
    DATA_PART = ""
    try:
        DATA_PART = plants.get_html_sensor_data(HTML_TABLE_ROW)
    except Exception as err:
        print("Error reading data.", err)
    return "".join([WEB_PART1, DATA_PART, WEB_PART2])

#
# clear_log()
#
# This function defines the route for clearing the log.
#
@ppwhttp.route("/CLEAR", methods=["GET"])
def clear_log(method, url, data=None):
    if method == "GET":
        plants.clear_log()
    addr = ".".join(map(str, ppwhttp.get_ip_address()))
    redirect = HTML_REDIRECT.format("http://{0}:80".format(addr))
    return "".join([WEB_PART1, redirect, WEB_PART2])

#
# read_sensors()
#
# This function runs as a separate thread to read the soil moisture sensors.
#
def read_sensors(plants):
    print("Reading sensors...")
    plants.read_sensors()
    print("Sensor read complete. Sleeping.")

#
# main()
#
# Setup the http server and run the main loop in a thread
def main():
    ppwhttp.start_wifi()
    server_sock = ppwhttp.start_server()
    utime.sleep(2)

    # Main loop for reading client requests    
    data_read_event = ReadEvent()
    while True:
        ppwhttp.handle_http_request(server_sock)
        utime.sleep(0.01)
        # Check to see if it is time to read the data
        if data_read_event.time_to_read():
            data_read_event.reset()
            # Handle the sensor reading loop on the other core!
            try:
                _thread.start_new_thread(read_sensors, [plants])
            except Exception as ex:
                print("ERROR: Cannot read sensors:", ex)
                sys.exit(1)


if __name__ == '__main__':
    try:
        main()
    except (KeyboardInterrupt, SystemExit) as err:
        print("\nbye!\n")        
sys.exit(0)
