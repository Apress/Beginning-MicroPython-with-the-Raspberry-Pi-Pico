#
# Beginning MicroPython
#
# Chapter 08 – Soil Moisture
#
# This file contains a class to display data from one or more soil
# moisture sensors. 
#
# Dr. Charles Bell
#
# Import libraries
from machine import Timer

# Constants
DATA_READ_INTERVAL = 120000          # Increase this interval as needed


# Class to control reading data with a timer
class ReadEvent:    
    def __init__(self):
        # Create and start the timer interrupt to read data
        self.data_read_event = True
        self.read_timer = Timer()
        self.read_timer.init(period=DATA_READ_INTERVAL, mode=Timer.PERIODIC, callback=self.read_data_event)

    # Callback for reading the data on the interval.
    def read_data_event(self, timer_obj):
        self.data_read_event = True
        
    # Check to see if it is time to read
    def time_to_read(self):
        return self.data_read_event
        
    # Reset the read event boolean (timer doesn't reset)
    def reset(self):
        self.data_read_event = False
        