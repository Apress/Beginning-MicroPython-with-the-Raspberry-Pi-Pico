"""vehicle.py"""
#
# Beginning MicroPython - Chapter 3
#
# Class Example: A generic vehicle
#
# Dr. Charles Bell
#
class Vehicle:
    """Base class for defining vehicles"""
    axles = 0
    doors = 0
    occupants = 0

    def __init__(self, num_axles, num_doors):
        """Constructor"""
        self.axles = num_axles
        self.doors = num_doors

    def get_axles(self):
        """Return number of axles"""
        return self.axles

    def get_doors(self):
        """Return number of doors"""
        return self.doors

    def add_occupant(self):
        """Add an occupant"""
        self.occupants += 1

    def num_occupants(self):
        """Return number of occupants"""
        return self.occupants
