"""roman_numerals.py"""
#
# Beginning MicroPython – Chapter 3
#
# Example: Roman numerals class
#
# Convert integers to roman numerals
# Convert roman numerals to integers
#
# Dr. Charles Bell
#

class Roman_Numerals:
    """Roman Numerals class"""

    # Private dictionary of roman numerals
    __roman_dict = {
        'I': 1,
        'IV': 4,
        'V': 5,
        'IX': 9,
        'X': 10,
        'XL': 40,
        'L': 50,
        'XC': 90,
        'C': 100,
        'CD': 400,
        'D': 500,
        'CM': 900,
        'M': 1000,
    }

    def convert_to_int(self, roman_num):
        """Convert Roman numeral to integer"""
        value = 0
        for i in range(len(roman_num)):
            if i > 0 and self.__roman_dict[roman_num[i]] > self.__roman_dict[roman_num[i - 1]]:
                value += self.__roman_dict[roman_num[i]] - 2 * self.__roman_dict[roman_num[i - 1]]
            else:
                value += self.__roman_dict[roman_num[i]]
        return value

    def __find_numeral(self, find_value):
        """Search the dictionary for the Roman numeral"""
        return [item[0] for item in self.__roman_dict.items() if item[1] == find_value][0]

    def __find_numeral_search(self, find_value):
        """Search the dictionary for the Roman numeral using a search"""
        for key in self.__roman_dict.keys():
            if self.__roman_dict[key] == find_value:
                return key
        return None

    def convert_to_roman(self, int_value):
        """Convert integer to Roman numeral"""
        # First, sort the dictionary by value
        
        roman_values = sorted(list(self.__roman_dict.values()))
        # Prepare the string
        roman_str = ""
        remainder = int_value
        # Loop through the values in reverse
        for i in range(len(roman_values)-1, -1, -1):
            count = int(remainder / roman_values[i])
            if count > 0:
                for j in range(0,count):
#                    roman_str += self.__find_numeral(roman_values[i])
                    roman_str += self.__find_numeral_search(roman_values[i])
                remainder -= count * roman_values[i]
        return roman_str
