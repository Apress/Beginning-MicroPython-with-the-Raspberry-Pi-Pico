"""rw_json.py"""
#
# Beginning MicroPython - Chapter 3
#
# Example: Storing and retrieving JSON objects in files
#
# Dr. Charles Bell
#
import json

# Prepare a list of JSON documents for pets by converting JSON to a dictionary
pets = []
parsed_json = json.loads('{"name":"Violet", "age": 11, "breed":"dachshund", "type":"dog"}')
pets.append(parsed_json)
parsed_json = json.loads('{"name": "Mister", "age": 16, "breed":"siberian khatru", "type":"cat"}')
pets.append(parsed_json)
parsed_json = json.loads('{"name": "Spot", "age": 13, "breed":"koi", "type":"fish"}')
pets.append(parsed_json)
parsed_json = json.loads('{"name": "Charlie", "age": 11, "breed":"dachshund", "type":"dog"}')
pets.append(parsed_json)

# Now, write these entries to a file. Note: overwrites the file
with open("my_data.json", "w") as json_file:
    for pet in pets:
        json_file.write(json.dumps(pet))
        json_file.write("\n")

# Now, let's read the JSON documents then print the name and age for all of the dogs in the list
my_pets = []
with open("my_data.json", "r") as json_file:
    for pet in json_file.readlines():
        parsed_json = json.loads(pet)
        my_pets.append(parsed_json)

print("Name, Age")
for pet in my_pets:
    if pet['type'] == 'dog':
        print("{0}, {1}".format(pet['name'], pet['age']))
