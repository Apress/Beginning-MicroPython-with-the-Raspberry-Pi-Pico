#
# Beginning MicroPython
#
# Chapter 07 – Pedestrian Crosswalk
#
# This example implements a Pedestrian Crosswalk Simulator
# controlling LEDs and button as input
#
# Dr. Charles Bell
#
# Import libraries
from machine import Pin
import utime

# Setup the button and LEDs
stoplight_red = Pin(13, Pin.OUT)
stoplight_yellow = Pin(12, Pin.OUT)
stoplight_green = Pin(11, Pin.OUT)
button = Pin(9, Pin.IN, Pin.PULL_DOWN)
pedestrian_red = Pin(8, Pin.OUT)
pedestrian_green = Pin(7, Pin.OUT)

# Setup lists for the LEDs
stoplight = [stoplight_red, stoplight_yellow, stoplight_green]
pedestrian_signal = [pedestrian_red, pedestrian_green]

# Turn off the LEDs
for led in stoplight:
    led.off()
for led in pedestrian_signal:
    led.off()

# Start with green stoplight and red pedestrian_signal
stoplight[2].on()
pedestrian_signal[0].on()

# We need a method to cycle the stoplight and pedestrian_signal
#
# We toggle from green to yellow for 2 seconds
# then red for 20 seconds.
def cycle_lights():
    # Go yellow.
    stoplight[2].off()
    stoplight[1].on()
    # Wait 2 seconds
    utime.sleep(2)
    # Go red and turn on walk light
    stoplight[1].off()
    stoplight[0].on()
    utime.sleep_ms(500)  # Give the pedestrian a chance to see it
    pedestrian_signal[0].off()
    pedestrian_signal[1].on()
    # After 10 seconds, start blinking the walk light
    utime.sleep(1)
    for i in range(0,10):
        pedestrian_signal[1].off()
        utime.sleep_ms(500)
        pedestrian_signal[1].on()
        utime.sleep_ms(500)
        
    # Stop=green, walk=red
    pedestrian_signal[1].off()
    pedestrian_signal[0].on()
    utime.sleep_ms(500)  # Give the pedestrian a chance to see it
    stoplight[0].off()
    stoplight[2].on()

# Create callback for the button
def button_pressed(line):
    cur_value = button.value()
    active = 0
    while (active < 50):
        if button.value() != cur_value:
            active += 1
        else:
            active = 0
        utime.sleep_ms(1)
        print("")
    if active:
        cycle_lights()
    else:
        print("False press")        

# Create an interrupt for the button
button.irq(trigger=Pin.IRQ_RISING, handler=button_pressed)
