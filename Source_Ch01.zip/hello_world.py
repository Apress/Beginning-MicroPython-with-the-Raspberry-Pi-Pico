"""hello_world.py"""
#
# Beginning MicroPython - Chapter 1
#
# Hello, World! Example
#
# Dr. Charles Bell (2021)
#
print("Hello, World!")
