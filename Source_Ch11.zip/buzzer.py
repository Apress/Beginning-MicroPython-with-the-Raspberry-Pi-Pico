"""buzzer.py"""
#
# Beginning MicroPython
#
# Chapter 11 - Simon Game
#
# This module is the source code for the Buzzer library.
#
# Functions are included that permit the caller to play an
# opening theme and tones for buttons, success, and failure.
#
# The class is used exclusively for the Simon Game and is
# based on the Sparkfun exampleanalogWrite(BUZZER code for the SIK Equipment
# experiment #11.
#
# See https:#learn.sparkfun.com/tutorials/sik-experiment-
#     guide-for-arduino---v32/experiment-11-using-a-piezo-buzzer.
#
# Dr. Charles Bell
#
#pylint: disable=import-error
from machine import Pin
from utime import sleep

# CONSTANTS
DEFAULT_TEMPO = 0.095
BUZZER_PIN = 26
NOTES_IN_SCALE = 8
HIGH = 1
LOW = 0

#
# tone()
#
# Use this function to play a tone on the buzzer.
# This is an adaptation from the example found at
# https://www.freva.com/2019/06/05/buzzer-on-raspberry-pi-playing-a-melody/
#
# frequency (int) - frequency to play for the note
# duration (int) - how long to play the tone/note
#
def tone(buzzer_pin, frequency, duration):
    """Generate a tone on the buzzer."""
    half_wave = 1 / (frequency * 2)
    waves = int(duration * frequency)
    # pylint: disable=unused-variable
    for i in range(waves):
        buzzer_pin.on()
        sleep(half_wave)
        buzzer_pin.off()
        sleep(half_wave)


class Buzzer:
    """Buzzer Class"""
    # The following arrays hold the note characters and their
    # corresponding frequencies. The last "C" note is uppercase
    # to separate it from the first lowercase "c". If you want to
    # add more notes, you'll need to use unique characters.
    note_names = ['c', 'd', 'e', 'f', 'g', 'a', 'b', 'C']
    frequencies = [131, 147, 165, 175, 196, 220, 247, 262]
    failure = {}
    success = {}
    theme_song = {}
    ready_set_go = {}
    colors = [{}, {}, {}, {}]

    #
    # constructor
    #
    # Setup the theme song and tones.
    #
    def __init__(self):
        """Constructor"""
        # Failure tones dictionary
        self.failure = {
            'tempo': DEFAULT_TEMPO,
            'num_notes': 5,
            'notes': "g g c",
            'beats': [4, 1, 4, 1, 10]
        }
        # Success tones dictionary
        self.success = {
            'tempo': DEFAULT_TEMPO,
            'num_notes': 3,
            'notes': "CCC",
            'beats': [1, 1, 1]
        }
        # Theme song dictionary
        self.theme_song = {
            'tempo': DEFAULT_TEMPO,
            'num_notes': 18,
            'notes': "cdfda ag cdfdg gf ",
            'beats': [1, 1, 1, 1, 1, 1, 4, 4, 2,
                      1, 1, 1, 1, 1, 1, 4, 4, 2]
        }
        # Start signal dictionary
        self.ready_set_go = {
            'tempo': DEFAULT_TEMPO,
            'num_notes': 1,
            'notes': "e",
            'beats': [2]
        }
        # Tones for the colors
        for i in range(0, 4):
            self.colors[i]['tempo'] = DEFAULT_TEMPO
            self.colors[i]['num_notes'] = 1
            self.colors[i]['beats'] = [1]
        self.colors[0]['notes'] = "a"
        self.colors[1]['notes'] = "g"
        self.colors[2]['notes'] = "C"
        self.colors[3]['notes'] = "f"

        # Setup the buzzer
        self.buzzer_pin = Pin(BUZZER_PIN, Pin.OUT)

    #
    # Play Theme Song
    #
    def play_theme_song(self):
        """Play theme_song tones."""
        self.play_song(self.theme_song)

    #
    # Play Success Sound
    #
    def play_success(self):
        """Play success tones."""
        self.play_song(self.success)

    #
    # Play Failure Sound
    #
    def play_failure(self):
        """Play failure tones."""
        self.play_song(self.failure)

    #
    # Play Button Color Sound
    #
    def play_color(self, color):
        """Play button_color tones."""
        self.play_song(self.colors[color])

    #
    # Play Ready_set_go Sound
    #
    def play_ready_set_go(self):
        """Play ready_set_go tones."""
        self.play_song(self.ready_set_go)

    #
    # frequency()
    #
    # This function takes a note character (a-g), and returns the
    # corresponding frequency in Hz for the tone() function.
    #
    # note (char) - the note to play
    #
    # Returns (int) - the frequency associated with the note
    #
    def frequency(self, note):
        """Get frequency for a note."""
        # Search through the letters in the array, and return the frequency for that note.
        for i in range(0, NOTES_IN_SCALE):
            if self.note_names[i] == note:
                return self.frequencies[i]
        return 0

    #
    # play_song()
    #
    # Play a song.
    #
    # song (dict) - dictionary for a song structure
    #
    def play_song(self, song):
        """Play a song."""
        for i in range(0, song['num_notes']):
            duration = song['beats'][i] * song['tempo']  # length of note/rest in ms
            if song['notes'][i] == ' ':                  # is this a rest?
                sleep(duration)                          # then pause for a moment
            else:                                        # otherwise, play the note
                freq = self.frequency(song['notes'][i])
                tone(self.buzzer_pin, freq, duration)
            sleep(duration)                         # wait for tone to finish
            sleep(song['tempo']/10)                 # brief pause between notes
