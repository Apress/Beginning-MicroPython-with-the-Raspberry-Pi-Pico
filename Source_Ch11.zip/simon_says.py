"""simon_says.py"""
#
# Beginning MicroPython
#
# Chapter 11 - Simon Game
#
# This module is the code module for the Simon library that
# manages a set of four LED buttons to produce a sequence
# of button presses. It can also validate a sequence to
# ensure the sequence matches.
#
# Functions are included that permit the caller to play
# an opening theme and tones for success and failure.
#
# The class is used exclusively for the Simon Game
# project.
#
# Dr. Charles Bell
#
#pylint: disable=import-error
import time
import urandom
from machine import ADC, I2C, Pin
from project5.buttons import Buttons
from project5.buzzer import Buzzer
from project5.lcd1602 import LCD1602_RGB, LCD1602
from project5.p9813 import P9813

# Constants
MIN_BEATS = 2        # Starting number of beats
MAX_PLAYERS = 4      # Max number of players
MAX_TIMEOUT = 5.0    # Seconds to wait to abort read
KEY_INTERVAL = 0.500 # Interval between button playback
# RGB Values
RED_LED = (255, 0, 0)
GREEN_LED = (0, 255, 0)
WHITE_LED = (200, 200, 200)
BLUE_LED = (0, 0, 255)
RGB_COLORS = (RED_LED, GREEN_LED, WHITE_LED, BLUE_LED)

#
# generate_sequence()
#
# Generate a new button sequence for current player.
#
def generate_sequence(num_notes):
    """Generate a new button sequence."""
    if num_notes == 0:
        return []
    # Create a new sequence adding a new beat
    challenge_sequence = []
    i = 0
    while i < num_notes:
        challenge_sequence.append(urandom.randint(0, 3))
        i = i + 1
    return challenge_sequence

class Simon:
    """Simon Class"""

    i2c = I2C(0,scl=Pin(9), sda=Pin(8), freq=400000)
    lcd = LCD1602(i2c, 2, 16)           # LCD
    lcd_rgb = LCD1602_RGB(i2c, 2, 16)   # LCD RGB control
    buzzer = Buzzer()                   # Buzzer
    buttons = Buttons()                 # Buttons
    num_players = 1
    player_scores = []
    # Setup the RGB module
    scl = Pin(7, Pin.OUT)
    sda = Pin(6, Pin.OUT)
    rgb_chain = P9813(scl, sda, 1)
    rgb_chain[0] = (0, 0, 0) # turn RGB off
    rgb_chain.write()

    #
    # constructor
    #
    # Setup the buttons.
    #
    def __init__(self):
        """Constructor"""
        # Setup the LCD
        self.lcd.clear()
        # Set background color?
        self.lcd_rgb.set_rgb(127, 127, 127)

        # if analog input pin 0 is unconnected, random analog
        # noise will cause the call to randomSeed() to generate
        # different seed numbers each time the sketch runs.
        # random.seed() will then shuffle the random function.
        urandom.seed(ADC(0).read_u16())

        print("Playing theme...")
        self.buzzer.play_theme_song()
        print("done.")

        # Put game in setup mode
        self.setup_mode()


    #
    # start_game
    #
    # Use this function to start a new game to display instructions.
    #
    def start_game(self, players):
        """Start a new game."""
        self.num_players = players
        for player in range(0, players):
            player_score = {
                'number': player,
                'is_alive': True,
                'high_score': 0
            }
            self.player_scores.append(player_score)
        self.reset_screen("Get ready!")

    #
    # play()
    #
    # Use this function to play the Simon game.
    #
    def play(self):
        """Play game."""
        game_over = False
        num_notes = 1

        # Main game loop
        while not game_over:
            # For each player, generate a new sequence and test skills
            for player in range(0, self.num_players):
                if self.player_scores[player]['is_alive']:
                    num_notes = self.player_scores[player]['high_score'] + 1
                    self.reset_screen("Player {0}".format(player + 1))
                    challenge_sequence = generate_sequence(num_notes)
                    self.play_sequence(challenge_sequence, num_notes)
                    self.buzzer.play_ready_set_go()
                    self.reset_screen("Go!")
                    print("Go!")
                    if self.read_sequence(challenge_sequence, num_notes):
                        self.buzzer.play_success()
                        self.reset_screen("Success!")
                        print("Success!")
                        time.sleep(0.500)
                        self.player_scores[player]['high_score'] = num_notes
                    else:
                        self.reset_screen("FAILED")
                        print("Fail")
                        self.player_scores[player]['is_alive'] = False
            # Check to see if any players remain alive
            # and show winner if multiple players
            players_remaining = self.num_alive()
            if players_remaining == 0:
                self.reset_screen("GAME OVER")
                if self.num_players > 1:
                    self.show_winner()
                game_over = True
                print("Game over...")
                time.sleep(2)
        self.player_scores = []

    #
    # setup_mode()
    #
    # Enter the setup mode and display on LCD.
    #
    def setup_mode(self):
        """Enter setup mode."""
        self.lcd.clear()
        self.lcd.setCursor(0, 0)
        self.lcd.print("Simon Says!")
        self.lcd.setCursor(0, 1) # column 1, row 2
        self.lcd.print("Setup Mode")

    #
    # show_players()
    #
    # Use this function to show the number of players
    # on the LCD.
    #
    # num_players (int) - number of players
    #
    def show_players(self, num_players):
        """Show players."""
        self.lcd.clear()
        self.lcd.setCursor(0, 0)
        self.lcd.print("Simon Says!")
        self.lcd.setCursor(0, 1) # column 1, row 2
        if num_players == 1:
            self.lcd.print("single player")
        else:
            self.lcd.print(chr(num_players + 0x30))
            self.lcd.print(" players")

    #
    # show_winner()
    #
    # Use this function to show the winner in a multi-user game.
    #
    def show_winner(self):
        """Show the winner."""
        winner = -1
        score = 0
        for player in range(0, self.num_players):
            if self.player_scores[player]['high_score'] > score:
                winner = player
                score = self.player_scores[player]['high_score']
        self.lcd.setCursor(0, 0)
        self.lcd.print("Player ")
        self.lcd.print(winner + 1)
        self.lcd.print("WON!")
        self.lcd.setCursor(0, 1) # column 1, row 2
        self.lcd.print("Score = ")
        self.lcd.print(score)

    #
    # num_alive()
    #
    # Get the number of players left alive (still playing).
    #
    # Returns (int) - number of players still alive
    #
    def num_alive(self):
        """Number of players still playing."""
        count = 0
        for player in range(0, self.num_players):
            if self.player_scores[player]['is_alive']:
                count = count + 1
        return count

    #
    # reset_screen()
    #
    # Reset the display to default message
    #
    def reset_screen(self, message):
        """Reset the LCD."""
        self.lcd.clear()
        self.lcd.setCursor(0, 0)
        self.lcd.print("Simon Says! (")
        self.lcd.print("{0}".format(self.num_players))
        self.lcd.print(")")
        self.lcd.setCursor(0, 1) # column 1, row 2
        self.lcd.print(message)

    #
    # read_sequence()
    #
    # Read a button sequence from the user. If sequence does not match, reset the
    # user's score.
    #
    # Returns (bool) - True if user pressed the correct sequence
    #
    def read_sequence(self, challenge_sequence, num_notes):
        """Read button sequence from the player."""

        def show_challenge_sequence():
            colors = ""
            for color in challenge_sequence:
                if color == 0:
                    colors += "R "
                elif color == 1:
                    colors += "G "
                elif color == 2:
                    colors += "W "
                elif color == 3:
                    colors += "B "
            return colors

        button_read = -1
        index = 0
        start_time = time.time()

        # Loop reading buttons and compare to stored sequence
        while index < num_notes:
            button_read = self.buttons.get_button_pressed() - 2
            # if a color button is pressed, check the sequence
            if button_read >= 0:
                print(">", button_read, show_challenge_sequence())
                if challenge_sequence[index] != button_read:
                    self.buzzer.play_failure()
                    self.reset_screen("FAIL SEQUENCE")
                    time.sleep(5)
                    return False
                print("MATCH!")
                start_time = time.time()
                index = index + 1
                button_read = -1
            if (time.time() - start_time) > MAX_TIMEOUT:
                print("ERROR: Timeout!")
                self.buzzer.play_failure()
                self.reset_screen("FAIL TIMEOUT")
                time.sleep(5)
                return False
            time.sleep(0.050)
        return True

    #
    # playSequence
    #
    # Play the button sequence for current player and turn on
    # LEDs for sequence.
    #
    def play_sequence(self, challenge_sequence, num_notes):
        """Play the tones and illuminate the buttons in the sequence."""
        for beat in range(0, num_notes):
            button_index = challenge_sequence[beat]
            self.rgb_chain[0] = RGB_COLORS[button_index]
            self.rgb_chain.write()
            self.buzzer.play_color(button_index)
            time.sleep(KEY_INTERVAL)
            self.rgb_chain[0] = (0, 0, 0) # turn RGB off
            self.rgb_chain.write()
            time.sleep(KEY_INTERVAL)
