"""buttons.py"""
#
# Beginning MicroPython
#
# Chapter 11 - Simon Game
#
# This module is the source code for the Buttons library.
#
# The class is used exclusively for the Simon Game. It is designed to
# capture when a button is pressed and return the button number via
# the get_button_pressed() function.
#
# Dr. Charles Bell
#
#pylint: disable=import-error
from machine import Pin
from utime import sleep

#
# button_name()
#
# Get the name of the button.
#
# button_num (int) - index for the button
#
# Returns (string) - name of the button
#
def button_name(button_num):
    """Return the name of the button for diagnostics."""
    name = ""
    if button_num == 0:
        name = "START_BUTTON"
    elif button_num == 1:
        name = "MODE_BUTTON"
    elif button_num == 2:
        name = "RED_BUTTON"
    elif button_num == 3:
        name = "GREEN_BUTTON"
    elif button_num == 4:
        name = "WHITE_BUTTON"
    else:
        name = "BLUE_BUTTON"
    return name

#
# debounce()
#
# Debounce the button pin.
#
# pin (int) - pin class instance for the button
#
def debounce(pin):
    """Debounce button presses."""
    # wait for pin to change value
    # it needs to be stable for a continuous 20ms
    cur_value = pin.value()
    active = 0
    while active < 20:
        if pin.value() != cur_value:
            active += 1
        else:
            active = 0
        sleep(0.01)


class Buttons:
    """Class to manage buttons for Simon game."""

    START_BUTTON = 0
    MODE_BUTTON = 1
    RED_BUTTON = 2
    GREEN_BUTTON = 3
    WHITE_BUTTON = 4
    BLUE_BUTTON = 5

    def __init__(self):
        self.button_list = []
        self.button_list.append(Pin(17, Pin.IN, Pin.PULL_UP))  # START
        self.button_list.append(Pin(16, Pin.IN, Pin.PULL_UP))  # MODE
        self.button_list.append(Pin(19, Pin.IN, Pin.PULL_UP))  # RED
        self.button_list.append(Pin(18, Pin.IN, Pin.PULL_UP))  # GREEN
        self.button_list.append(Pin(20, Pin.IN, Pin.PULL_UP))  # WHITE
        self.button_list.append(Pin(21, Pin.IN, Pin.PULL_UP))  # BLUE

    def get_button_pressed(self):
        """Return the button (index) pressed."""
        for button_num in range(0,6):
            if self.button_list[button_num].value() == 0:
                debounce(self.button_list[button_num])
                return button_num
        return -1

    def get_button_value(self, button_num):
        """Check a button for status."""
        return self.button_list[button_num].value()

if __name__ == '__main__':
    try:
        buttons = Buttons()
        while True:
            index = buttons.get_button_pressed()
            if index >= 0:
                print("{} = {} pressed".format(index, button_name(index)))

    except (KeyboardInterrupt, SystemExit) as err:
        print("\nbye!\n")
