"""main.py"""
#
# Beginning MicroPython
#
# Chapter 11 - Simon Says
#
# This example uses a series of buttons and button LEDs to
# simulate the Simon Says game where players must repeat a
# series of button presses displayed by the colored LEDs.
#
# If the sequence matches, a new random sequence is generated
# and play continues until the player misses a sequence.
#
# Each sequence or turn represents a level and the number of
# button presses increases for each level. In addition the
# player has a timeout value where she must complete the
# sequence before time expires.
#
# When playing, you will here a challenge sequence presented
# with lighting of the LEDs in the sequence and their tones.
# At the end of the sequence, you will hear a short 3-note
# tone to signal you can attempt to reproduce the sequence.
#
# If you get the sequence correct, you will hear a short
# high 3-note sequence and the next challenge sequence is
# played.
#
# There are two buttons one to start the game and the other
# to toggle one or two player mode (only available at start
# of a game).
#
# Dr. Charles Bell
#
#pylint: disable=import-error
# Import libraries
from time import sleep
from project5.simon_says import Simon, MAX_PLAYERS
from project5.buttons import Buttons

#
# main()
#
# Main script to run the Simon Says game.
#
def main():
    """Main"""
    print("Welcome to the Simon Says game!")
    simon = Simon()
    game_started = False
    start_button = False
    mode_button = False
    num_players = 1
    buttons = Buttons()
    while True:
        if not game_started:
            # Show number of players
            start_button = buttons.get_button_value(Buttons.START_BUTTON) == 0
            mode_button = buttons.get_button_value(Buttons.MODE_BUTTON) == 0
            if start_button:
                print("Start button pressed.")
                simon.start_game(num_players)
                sleep(1)
                simon.play()
                sleep(1)
                simon.setup_mode()
            elif mode_button:
                num_players = num_players + 1
                if num_players > MAX_PLAYERS:
                    num_players = 1
                print("Mode button pressed - {0} players."
                      "".format(num_players))
                sleep(0.050)
                simon.show_players(num_players)
                sleep(2)
                simon.setup_mode()

if __name__ == '__main__':
    try:
        main()
    except (KeyboardInterrupt, SystemExit) as err:
        print("\nbye!\n")
